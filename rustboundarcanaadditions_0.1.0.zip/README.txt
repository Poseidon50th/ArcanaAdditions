Rustbound Arcana Additions (0.1.0)
==================================

This is a content-only addon mod intended to be used with:
- Rustbound Magic (modid: rustboundmagic) v3.1.13
- RustboundAltered (modid: rustboundaltered) v1.0.0

It starts as an empty shell so you can confirm dependency loading.
New spells/rituals will be added in subsequent versions.
