RustboundAltered (v1.0.0)

What this is
- A single combined mod that includes:
  1) Mythic Legends (Rarer Wyverns) content (wyverns + related assets)
  2) Rustbound Magic - Balance Patch (Poseidon) content overrides + bundled default config files

Dependencies
- Rustbound Magic v3.1.13 (required)

Install
1) Make sure rustboundmagic_3.1.13.zip is installed/enabled.
2) Remove/disable these if you had them installed separately:
   - Mythic Legends (Rarer Wyverns)
   - Rustbound Magic - Balance Patch (Poseidon)
3) Drop RustboundAltered_1.0.0.zip into your VintageStory Mods folder.

Notes about config
- This mod bundles default Rustbound Magic config files in /ModConfig/.
- If you already have RustboundMagicConfig.json / RustboundMagicSpellConfig.json in your VintagestoryData/ModConfig folder,
  Vintage Story will usually keep your existing files.
  If you want the bundled defaults to take effect, back up and delete/rename your existing ModConfig files,
  then launch the game once to let them be recreated.
